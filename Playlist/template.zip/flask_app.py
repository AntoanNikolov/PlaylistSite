# A very simple Flask Hello World app for you to get started with...

from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from socket import gethostname
import math


numPageLoads = 0

# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
# initialize the app with the extension
# create the extension
db = SQLAlchemy(app)

class Comment(db.Model):
    __tablename__ = "comments"
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(4096))

@app.route('/')
def hello_world():
    global numPageLoads
    numPageLoads+=1
    return 'Hello from Flask!\nThis page has been loaded ' + str(numPageLoads) + ' times'

###
# The /triangle URL is associated with the triangle function
####
@app.route('/triangle', methods=['POST', 'GET'])
def triangle():
    if request.method == 'GET':
        return render_template('pythagorean_input.html')
    if request.method == 'POST':
        a = int(request.form['a'])
        b = int(request.form['b'])

        c = math.sqrt(a*a + b*b)

        return render_template('pythagorean_result.html', a=a, b=b, c=c)

@app.route('/comments')
def comments():
    comments = Comment.query.all()
    return render_template('comments.html', comments=comments)

if __name__ == '__main__':
    with app.app_context():
        db.drop_all()
        db.create_all()
        #manually add some comments
        db.session.add(Comment(text="This is my first comment"))
        db.session.add(Comment(text="Hey - cool website!"))
        db.session.commit()
    if 'liveconsole' not in gethostname():
        app.run()
